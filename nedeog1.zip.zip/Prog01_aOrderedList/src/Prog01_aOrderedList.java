import java.io.*;
import java.util.*;

public class Prog01_aOrderedList {
    public static void main(String[] args) {
        aOrderedList orderedList = new aOrderedList();
        try {
            Scanner inputFile = getInputFile("Enter input filename: ");
            PrintWriter outputFile = getOutputFile("Enter output filename: ");

            while (inputFile.hasNextLine()) {
                String line = inputFile.nextLine();
                String[] parts = line.split(",");
                String operation = parts[0];
                if (operation.equals("A")) {
                    orderedList.add(new Car(parts[1], Integer.parseInt(parts[2]), Integer.parseInt(parts[3])));
                } else if (operation.equals("D")) {
                    orderedList.remove(parts[1], Integer.parseInt(parts[2]));
                }
            }

            outputFile.println("Number of cars: " + orderedList.size());
            for (Car car : orderedList.getCars()) {
                outputFile.println(car);
            }

            inputFile.close();
            outputFile.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static Scanner getInputFile(String userPrompt) throws FileNotFoundException {
        Scanner inputScanner = null;
        boolean validInput = false;

        while (!validInput) {
            System.out.print(userPrompt);
            String inputFileName = System.console().readLine();

            try {
                inputScanner = new Scanner(new File(inputFileName));
                validInput = true;
            } catch (FileNotFoundException e) {
                System.out.println("File specified <" + inputFileName + "> does not exist.");
                String continuePrompt = System.console().readLine("Would you like to continue? <Y/N> ").toUpperCase();

                if (!continuePrompt.equals("Y")) {
                    throw e;
                }
            }
        }

        return inputScanner;
    }

    public static PrintWriter getOutputFile(String userPrompt) throws FileNotFoundException {
        PrintWriter outputWriter = null;
        boolean validInput = false;

        while (!validInput) {
            System.out.print(userPrompt);
            String outputFileName = System.console().readLine();

            try {
                outputWriter = new PrintWriter(new File(outputFileName));
                validInput = true;
            } catch (FileNotFoundException e) {
                System.out.println("File specified <" + outputFileName + "> does not exist.");
                String continuePrompt = System.console().readLine("Would you like to continue? <Y/N> ").toUpperCase();
                if (!continuePrompt.equals("Y")) {
                    throw e;
                }
            }
        }

        return outputWriter;
    }
}

class Car implements Comparable<Car> {
    private String make;
    private int year;
    private int price;

    public Car(String make, int year, int price) {
        this.make = make;
        this.year = year;
        this. price = price;
    }

    public String getMake() {
        return make;
    }

    public int getYear() {
        return year;
    }

    public int getPrice() {
        return price;
    }

    public int compareTo(Car other) {
        if (!make.equals(other.make)) {
            return make.compareTo(other.make);
        }
        return Integer.compare(year, other.year);
    }

    @Override
    public String toString() {
        return "Make: " + make + ", Year: " + year + ", Price: $" + price;
    }
}

class aOrderedList {
    private final int SIZEINCREMENTS = 20;
    private List<Car> cars = new ArrayList<>();
    
    public void add(Car car) {
        int index = Collections.binarySearch(cars, car);
        if (index < 0) {
            index = -index - 1;
        }
        cars.add(index, car);
    }

    public void remove(String make, int year) {
        cars.removeIf(car -> car.getMake().equals(make) && car.getYear() == year);
    }

    public int size() {
        return cars.size();
    }

    public List<Car> getCars() {
        return cars;
    }
}

